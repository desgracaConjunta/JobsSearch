<?php
/**
 * This interface defines the contract of a result.
 */
interface Result {
	public function render ($request);
}
?>
