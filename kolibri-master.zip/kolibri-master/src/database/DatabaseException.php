<?php
/**
 * General exception for database-related error conditions.
 */
class DatabaseException extends Exception {}
?>
